﻿namespace Remont_PC
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.справочникиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.статусToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.типОбращенияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.манипуляцииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.типОборудованияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.типПользователяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.производительToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справочникОборудованияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.пользовательToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.обращениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запЧастиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.обращениеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ремонтToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчётыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчёт1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчёт2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.statusStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 433);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(993, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.справочникиToolStripMenuItem,
            this.пользовательToolStripMenuItem,
            this.обращениеToolStripMenuItem,
            this.отчётыToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(993, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // справочникиToolStripMenuItem
            // 
            this.справочникиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.статусToolStripMenuItem,
            this.типОбращенияToolStripMenuItem,
            this.манипуляцииToolStripMenuItem,
            this.типОборудованияToolStripMenuItem,
            this.типПользователяToolStripMenuItem,
            this.производительToolStripMenuItem,
            this.справочникОборудованияToolStripMenuItem});
            this.справочникиToolStripMenuItem.Name = "справочникиToolStripMenuItem";
            this.справочникиToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.справочникиToolStripMenuItem.Text = "Справочники";
            // 
            // статусToolStripMenuItem
            // 
            this.статусToolStripMenuItem.Name = "статусToolStripMenuItem";
            this.статусToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.статусToolStripMenuItem.Text = "Статус";
            this.статусToolStripMenuItem.Click += new System.EventHandler(this.статусToolStripMenuItem_Click);
            // 
            // типОбращенияToolStripMenuItem
            // 
            this.типОбращенияToolStripMenuItem.Name = "типОбращенияToolStripMenuItem";
            this.типОбращенияToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.типОбращенияToolStripMenuItem.Text = "Тип обращения";
            this.типОбращенияToolStripMenuItem.Click += new System.EventHandler(this.типОбращенияToolStripMenuItem_Click);
            // 
            // манипуляцииToolStripMenuItem
            // 
            this.манипуляцииToolStripMenuItem.Name = "манипуляцииToolStripMenuItem";
            this.манипуляцииToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.манипуляцииToolStripMenuItem.Text = "Вид работ";
            this.манипуляцииToolStripMenuItem.Click += new System.EventHandler(this.манипуляцииToolStripMenuItem_Click);
            // 
            // типОборудованияToolStripMenuItem
            // 
            this.типОборудованияToolStripMenuItem.Name = "типОборудованияToolStripMenuItem";
            this.типОборудованияToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.типОборудованияToolStripMenuItem.Text = "Тип оборудования";
            this.типОборудованияToolStripMenuItem.Click += new System.EventHandler(this.типОборудованияToolStripMenuItem_Click);
            // 
            // типПользователяToolStripMenuItem
            // 
            this.типПользователяToolStripMenuItem.Name = "типПользователяToolStripMenuItem";
            this.типПользователяToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.типПользователяToolStripMenuItem.Text = "Тип пользователя";
            this.типПользователяToolStripMenuItem.Click += new System.EventHandler(this.типПользователяToolStripMenuItem_Click);
            // 
            // производительToolStripMenuItem
            // 
            this.производительToolStripMenuItem.Name = "производительToolStripMenuItem";
            this.производительToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.производительToolStripMenuItem.Text = "Производитель";
            this.производительToolStripMenuItem.Click += new System.EventHandler(this.производительToolStripMenuItem_Click);
            // 
            // справочникОборудованияToolStripMenuItem
            // 
            this.справочникОборудованияToolStripMenuItem.Name = "справочникОборудованияToolStripMenuItem";
            this.справочникОборудованияToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.справочникОборудованияToolStripMenuItem.Text = "Справочник оборудования";
            this.справочникОборудованияToolStripMenuItem.Click += new System.EventHandler(this.справочникОборудованияToolStripMenuItem_Click);
            // 
            // пользовательToolStripMenuItem
            // 
            this.пользовательToolStripMenuItem.Name = "пользовательToolStripMenuItem";
            this.пользовательToolStripMenuItem.Size = new System.Drawing.Size(96, 20);
            this.пользовательToolStripMenuItem.Text = "Пользователь";
            this.пользовательToolStripMenuItem.Click += new System.EventHandler(this.пользовательToolStripMenuItem_Click);
            // 
            // обращениеToolStripMenuItem
            // 
            this.обращениеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.запЧастиToolStripMenuItem,
            this.обращениеToolStripMenuItem1,
            this.ремонтToolStripMenuItem});
            this.обращениеToolStripMenuItem.Name = "обращениеToolStripMenuItem";
            this.обращениеToolStripMenuItem.Size = new System.Drawing.Size(85, 20);
            this.обращениеToolStripMenuItem.Text = "Обращение";
            // 
            // запЧастиToolStripMenuItem
            // 
            this.запЧастиToolStripMenuItem.Name = "запЧастиToolStripMenuItem";
            this.запЧастиToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.запЧастиToolStripMenuItem.Text = "Зап. части";
            this.запЧастиToolStripMenuItem.Click += new System.EventHandler(this.запЧастиToolStripMenuItem_Click);
            // 
            // обращениеToolStripMenuItem1
            // 
            this.обращениеToolStripMenuItem1.Name = "обращениеToolStripMenuItem1";
            this.обращениеToolStripMenuItem1.Size = new System.Drawing.Size(140, 22);
            this.обращениеToolStripMenuItem1.Text = "Обращение";
            this.обращениеToolStripMenuItem1.Click += new System.EventHandler(this.обращениеToolStripMenuItem1_Click);
            // 
            // ремонтToolStripMenuItem
            // 
            this.ремонтToolStripMenuItem.Name = "ремонтToolStripMenuItem";
            this.ремонтToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.ремонтToolStripMenuItem.Text = "Ремонт";
            this.ремонтToolStripMenuItem.Click += new System.EventHandler(this.ремонтToolStripMenuItem_Click);
            // 
            // отчётыToolStripMenuItem
            // 
            this.отчётыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.отчёт1ToolStripMenuItem,
            this.отчёт2ToolStripMenuItem});
            this.отчётыToolStripMenuItem.Name = "отчётыToolStripMenuItem";
            this.отчётыToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.отчётыToolStripMenuItem.Text = "Отчёты";
            // 
            // отчёт1ToolStripMenuItem
            // 
            this.отчёт1ToolStripMenuItem.Name = "отчёт1ToolStripMenuItem";
            this.отчёт1ToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.отчёт1ToolStripMenuItem.Text = "Отчёт №1";
            this.отчёт1ToolStripMenuItem.Click += new System.EventHandler(this.отчёт1ToolStripMenuItem_Click);
            // 
            // отчёт2ToolStripMenuItem
            // 
            this.отчёт2ToolStripMenuItem.Name = "отчёт2ToolStripMenuItem";
            this.отчёт2ToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.отчёт2ToolStripMenuItem.Text = "Отчёт №2";
            this.отчёт2ToolStripMenuItem.Click += new System.EventHandler(this.отчёт2ToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::Remont_PC.Properties.Resources.xXDTPMRoyXo;
            this.pictureBox1.Location = new System.Drawing.Point(0, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(993, 409);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(993, 455);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Автоматизированная информационная система учета заявок на ремонт компьютерной тех" +
    "ники в ГАПОУ \"Акбулакский политехнический техникум\"";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem справочникиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem статусToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem типОбращенияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem манипуляцииToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem типОборудованияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem типПользователяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem производительToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справочникОборудованияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem пользовательToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem обращениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запЧастиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ремонтToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem обращениеToolStripMenuItem1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripMenuItem отчётыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчёт1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчёт2ToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

