﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Remont_PC
{
    public partial class RemontForm : Form
    {
        public RemontForm()
        {
            InitializeComponent();
        }

        private void RemontForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_db_pc_techDataSet.Obrash". При необходимости она может быть перемещена или удалена.
            this.obrashTableAdapter.Fill(this._db_pc_techDataSet.Obrash);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_db_pc_techDataSet.Zap_chast". При необходимости она может быть перемещена или удалена.
            this.zap_chastTableAdapter.Fill(this._db_pc_techDataSet.Zap_chast);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_db_pc_techDataSet.Manipul". При необходимости она может быть перемещена или удалена.
            this.manipulTableAdapter.Fill(this._db_pc_techDataSet.Manipul);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_db_pc_techDataSet.Remont". При необходимости она может быть перемещена или удалена.
            this.remontTableAdapter.Fill(this._db_pc_techDataSet.Remont);

            toolStripStatusLabel1.Text = "Кол-во записей " +
                bindingNavigatorCountItem.Text.Remove(0, bindingNavigatorCountItem.Text.IndexOf(' '));

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.remontTableAdapter.Update(this._db_pc_techDataSet);
        }
    }
}
