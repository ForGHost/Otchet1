﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Remont_PC
{
    public partial class ObrashForm : Form
    {
        public ObrashForm()
        {
            InitializeComponent();
        }

        private void ObrashForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_db_pc_techDataSet.Polzov". При необходимости она может быть перемещена или удалена.
            this.polzovTableAdapter.Fill(this._db_pc_techDataSet.Polzov);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_db_pc_techDataSet.Ssprav_oborud". При необходимости она может быть перемещена или удалена.
            this.ssprav_oborudTableAdapter.Fill(this._db_pc_techDataSet.Ssprav_oborud);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_db_pc_techDataSet.Type_obr". При необходимости она может быть перемещена или удалена.
            this.type_obrTableAdapter.Fill(this._db_pc_techDataSet.Type_obr);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_db_pc_techDataSet.Status". При необходимости она может быть перемещена или удалена.
            this.statusTableAdapter.Fill(this._db_pc_techDataSet.Status);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_db_pc_techDataSet.Obrash". При необходимости она может быть перемещена или удалена.
            this.obrashTableAdapter.Fill(this._db_pc_techDataSet.Obrash);
            toolStripStatusLabel1.Text = "Кол-во записей " +
                bindingNavigatorCountItem.Text.Remove(0, bindingNavigatorCountItem.Text.IndexOf(' '));

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.obrashTableAdapter.Update(this._db_pc_techDataSet);
        }
    }
}
