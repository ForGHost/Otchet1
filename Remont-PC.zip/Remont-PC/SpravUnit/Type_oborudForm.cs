﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Remont_PC
{
    public partial class Type_oborudForm : Form
    {
        public Type_oborudForm()
        {
            InitializeComponent();
        }

        private void Type_oborudForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_db_pc_techDataSet.Type_oborud". При необходимости она может быть перемещена или удалена.
            this.type_oborudTableAdapter.Fill(this._db_pc_techDataSet.Type_oborud);

            toolStripStatusLabel1.Text = "Кол-во записей " +
                bindingNavigatorCountItem.Text.Remove(0, bindingNavigatorCountItem.Text.IndexOf(' '));
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.type_oborudTableAdapter.Update(this._db_pc_techDataSet);
        }
    }
}
