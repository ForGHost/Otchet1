﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Remont_PC
{
    public partial class Type_obrForm : Form
    {
        public Type_obrForm()
        {
            InitializeComponent();
        }

        private void Type_obrForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_db_pc_techDataSet.Type_obr". При необходимости она может быть перемещена или удалена.
            this.type_obrTableAdapter.Fill(this._db_pc_techDataSet.Type_obr);

            toolStripStatusLabel1.Text = "Кол-во записей " +
                bindingNavigatorCountItem.Text.Remove(0, bindingNavigatorCountItem.Text.IndexOf(' '));

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.type_obrTableAdapter.Update(this._db_pc_techDataSet);
        }
    }
}
