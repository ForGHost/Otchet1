﻿namespace Remont_PC
{
    partial class ReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this._db_pc_techDataSet = new Remont_PC._db_pc_techDataSet();
            this.ObrashBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ObrashTableAdapter = new Remont_PC._db_pc_techDataSetTableAdapters.ObrashTableAdapter();
            this.PolzovBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.PolzovTableAdapter = new Remont_PC._db_pc_techDataSetTableAdapters.PolzovTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this._db_pc_techDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ObrashBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PolzovBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource2.Name = "DataSet1";
            reportDataSource2.Value = this.PolzovBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Remont_PC.ReportUnit.Report2.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(612, 481);
            this.reportViewer1.TabIndex = 0;
            // 
            // _db_pc_techDataSet
            // 
            this._db_pc_techDataSet.DataSetName = "_db_pc_techDataSet";
            this._db_pc_techDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ObrashBindingSource
            // 
            this.ObrashBindingSource.DataMember = "Obrash";
            this.ObrashBindingSource.DataSource = this._db_pc_techDataSet;
            // 
            // ObrashTableAdapter
            // 
            this.ObrashTableAdapter.ClearBeforeFill = true;
            // 
            // PolzovBindingSource
            // 
            this.PolzovBindingSource.DataMember = "Polzov";
            this.PolzovBindingSource.DataSource = this._db_pc_techDataSet;
            // 
            // PolzovTableAdapter
            // 
            this.PolzovTableAdapter.ClearBeforeFill = true;
            // 
            // ReportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(612, 481);
            this.Controls.Add(this.reportViewer1);
            this.Name = "ReportForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Отчёт";
            this.Load += new System.EventHandler(this.ReportForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this._db_pc_techDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ObrashBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PolzovBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource ObrashBindingSource;
        private _db_pc_techDataSet _db_pc_techDataSet;
        private _db_pc_techDataSetTableAdapters.ObrashTableAdapter ObrashTableAdapter;
        private System.Windows.Forms.BindingSource PolzovBindingSource;
        private _db_pc_techDataSetTableAdapters.PolzovTableAdapter PolzovTableAdapter;
    }
}