﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Remont_PC
{
    public partial class ReportForm2 : Form
    {
        public ReportForm2()
        {
            InitializeComponent();
        }

        private void ReportForm2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_db_pc_techDataSet.Ssprav_oborud". При необходимости она может быть перемещена или удалена.
            this.Ssprav_oborudTableAdapter.Fill(this._db_pc_techDataSet.Ssprav_oborud);

            this.reportViewer1.RefreshReport();
        }
    }
}
