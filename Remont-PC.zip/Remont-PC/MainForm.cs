﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Remont_PC
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void статусToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StatusForm frm = new StatusForm();
            frm.ShowDialog();

        }

        private void типОбращенияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Type_obrForm frm = new Type_obrForm();
            frm.ShowDialog();
        }

        private void манипуляцииToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManuForm frm = new ManuForm();
            frm.ShowDialog();
        }

        private void типПользователяToolStripMenuItem_Click(object sender, EventArgs e)
        {
           Type_polzavtForm frm = new Type_polzavtForm();
           frm.ShowDialog();
        }

        private void типОборудованияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Type_oborudForm frm = new Type_oborudForm();
            frm.ShowDialog();
        }

        private void производительToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProizvodForm frm = new ProizvodForm();
            frm.ShowDialog();
        }

        private void запасныеЧастиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ZapCastForm frm = new ZapCastForm();
            frm.ShowDialog();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void справочникОборудованияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SpravOborudForm frm = new SpravOborudForm();
            frm.ShowDialog();
        }

        private void запЧастиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ZapCastForm frm = new ZapCastForm();
            frm.ShowDialog();
        }

        private void ремонтToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RemontForm frm = new RemontForm();
            frm.ShowDialog();
        }

        private void обращениеToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ObrashForm frm = new ObrashForm();
            frm.ShowDialog();
        }

        private void пользовательToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PolzovForm frm = new PolzovForm();
            frm.ShowDialog();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Время подключения: "+ DateTime.Now.ToString();
        }

        private void отчёт1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReportForm frm = new ReportForm();
            frm.ShowDialog();
        }

        private void отчёт2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReportForm2 frm = new ReportForm2();
            frm.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
