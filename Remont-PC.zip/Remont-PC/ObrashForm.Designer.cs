﻿namespace Remont_PC
{
    partial class ObrashForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ObrashForm));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.obrashBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this._db_pc_techDataSet = new Remont_PC._db_pc_techDataSet();
            this.statusBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.obrashBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.typeobrBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sspravoborudBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sspravoborudBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.polzovBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.polzovBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.polzovBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.obrashTableAdapter = new Remont_PC._db_pc_techDataSetTableAdapters.ObrashTableAdapter();
            this.statusTableAdapter = new Remont_PC._db_pc_techDataSetTableAdapters.StatusTableAdapter();
            this.type_obrTableAdapter = new Remont_PC._db_pc_techDataSetTableAdapters.Type_obrTableAdapter();
            this.ssprav_oborudTableAdapter = new Remont_PC._db_pc_techDataSetTableAdapters.Ssprav_oborudTableAdapter();
            this.polzovTableAdapter = new Remont_PC._db_pc_techDataSetTableAdapters.PolzovTableAdapter();
            this.obrashBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.codDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataregDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datarazreshDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.opisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.otlojDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.typeobrashDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.spravpoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.spravoborudDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.polz1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.polz2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.polz3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.obrashBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._db_pc_techDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.obrashBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeobrBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sspravoborudBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sspravoborudBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.polzovBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.polzovBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.polzovBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.obrashBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 643);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1380, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = this.bindingNavigatorAddNewItem;
            this.bindingNavigator1.CountItem = this.bindingNavigatorCountItem;
            this.bindingNavigator1.DeleteItem = this.bindingNavigatorDeleteItem;
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.toolStripButton1,
            this.bindingNavigatorDeleteItem});
            this.bindingNavigator1.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigator1.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigator1.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigator1.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigator1.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingNavigator1.Size = new System.Drawing.Size(1380, 25);
            this.bindingNavigator1.TabIndex = 1;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // obrashBindingSource
            // 
            this.obrashBindingSource.DataMember = "Obrash";
            this.obrashBindingSource.DataSource = this.bindingSource1;
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataSource = this._db_pc_techDataSet;
            this.bindingSource1.Position = 0;
            // 
            // _db_pc_techDataSet
            // 
            this._db_pc_techDataSet.DataSetName = "_db_pc_techDataSet";
            this._db_pc_techDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // statusBindingSource
            // 
            this.statusBindingSource.DataMember = "Status";
            this.statusBindingSource.DataSource = this.bindingSource1;
            // 
            // obrashBindingSource1
            // 
            this.obrashBindingSource1.DataMember = "Obrash";
            this.obrashBindingSource1.DataSource = this.bindingSource1;
            // 
            // typeobrBindingSource
            // 
            this.typeobrBindingSource.DataMember = "Type_obr";
            this.typeobrBindingSource.DataSource = this.bindingSource1;
            // 
            // sspravoborudBindingSource
            // 
            this.sspravoborudBindingSource.DataMember = "Ssprav_oborud";
            this.sspravoborudBindingSource.DataSource = this.bindingSource1;
            // 
            // sspravoborudBindingSource1
            // 
            this.sspravoborudBindingSource1.DataMember = "Ssprav_oborud";
            this.sspravoborudBindingSource1.DataSource = this.bindingSource1;
            // 
            // polzovBindingSource
            // 
            this.polzovBindingSource.DataMember = "Polzov";
            this.polzovBindingSource.DataSource = this.bindingSource1;
            // 
            // polzovBindingSource1
            // 
            this.polzovBindingSource1.DataMember = "Polzov";
            this.polzovBindingSource1.DataSource = this.bindingSource1;
            // 
            // polzovBindingSource2
            // 
            this.polzovBindingSource2.DataMember = "Polzov";
            this.polzovBindingSource2.DataSource = this.bindingSource1;
            // 
            // obrashTableAdapter
            // 
            this.obrashTableAdapter.ClearBeforeFill = true;
            // 
            // statusTableAdapter
            // 
            this.statusTableAdapter.ClearBeforeFill = true;
            // 
            // type_obrTableAdapter
            // 
            this.type_obrTableAdapter.ClearBeforeFill = true;
            // 
            // ssprav_oborudTableAdapter
            // 
            this.ssprav_oborudTableAdapter.ClearBeforeFill = true;
            // 
            // polzovTableAdapter
            // 
            this.polzovTableAdapter.ClearBeforeFill = true;
            // 
            // obrashBindingSource2
            // 
            this.obrashBindingSource2.DataMember = "Obrash";
            this.obrashBindingSource2.DataSource = this.bindingSource1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.codDataGridViewTextBoxColumn,
            this.nomerDataGridViewTextBoxColumn,
            this.dataregDataGridViewTextBoxColumn,
            this.datarazreshDataGridViewTextBoxColumn,
            this.opisDataGridViewTextBoxColumn,
            this.otlojDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn,
            this.typeobrashDataGridViewTextBoxColumn,
            this.spravpoDataGridViewTextBoxColumn,
            this.spravoborudDataGridViewTextBoxColumn,
            this.polz1DataGridViewTextBoxColumn,
            this.polz2DataGridViewTextBoxColumn,
            this.polz3DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.obrashBindingSource2;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 25);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1380, 618);
            this.dataGridView1.TabIndex = 7;
            // 
            // codDataGridViewTextBoxColumn
            // 
            this.codDataGridViewTextBoxColumn.DataPropertyName = "cod";
            this.codDataGridViewTextBoxColumn.HeaderText = "Код";
            this.codDataGridViewTextBoxColumn.Name = "codDataGridViewTextBoxColumn";
            this.codDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nomerDataGridViewTextBoxColumn
            // 
            this.nomerDataGridViewTextBoxColumn.DataPropertyName = "nomer";
            this.nomerDataGridViewTextBoxColumn.HeaderText = "Номер";
            this.nomerDataGridViewTextBoxColumn.Name = "nomerDataGridViewTextBoxColumn";
            // 
            // dataregDataGridViewTextBoxColumn
            // 
            this.dataregDataGridViewTextBoxColumn.DataPropertyName = "data_reg";
            this.dataregDataGridViewTextBoxColumn.HeaderText = "дата регистрации";
            this.dataregDataGridViewTextBoxColumn.Name = "dataregDataGridViewTextBoxColumn";
            // 
            // datarazreshDataGridViewTextBoxColumn
            // 
            this.datarazreshDataGridViewTextBoxColumn.DataPropertyName = "data_razresh";
            this.datarazreshDataGridViewTextBoxColumn.HeaderText = "Дата разрешения";
            this.datarazreshDataGridViewTextBoxColumn.Name = "datarazreshDataGridViewTextBoxColumn";
            // 
            // opisDataGridViewTextBoxColumn
            // 
            this.opisDataGridViewTextBoxColumn.DataPropertyName = "opis";
            this.opisDataGridViewTextBoxColumn.HeaderText = "Описание";
            this.opisDataGridViewTextBoxColumn.Name = "opisDataGridViewTextBoxColumn";
            // 
            // otlojDataGridViewTextBoxColumn
            // 
            this.otlojDataGridViewTextBoxColumn.DataPropertyName = "otloj";
            this.otlojDataGridViewTextBoxColumn.HeaderText = "Отложено";
            this.otlojDataGridViewTextBoxColumn.Name = "otlojDataGridViewTextBoxColumn";
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "status";
            this.statusDataGridViewTextBoxColumn.DataSource = this.statusBindingSource;
            this.statusDataGridViewTextBoxColumn.DisplayMember = "nazv";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Статус";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            this.statusDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.statusDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.statusDataGridViewTextBoxColumn.ValueMember = "cod";
            // 
            // typeobrashDataGridViewTextBoxColumn
            // 
            this.typeobrashDataGridViewTextBoxColumn.DataPropertyName = "type_obrash";
            this.typeobrashDataGridViewTextBoxColumn.DataSource = this.typeobrBindingSource;
            this.typeobrashDataGridViewTextBoxColumn.DisplayMember = "nazv";
            this.typeobrashDataGridViewTextBoxColumn.HeaderText = "Тип обрацения";
            this.typeobrashDataGridViewTextBoxColumn.Name = "typeobrashDataGridViewTextBoxColumn";
            this.typeobrashDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.typeobrashDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.typeobrashDataGridViewTextBoxColumn.ValueMember = "cod";
            // 
            // spravpoDataGridViewTextBoxColumn
            // 
            this.spravpoDataGridViewTextBoxColumn.DataPropertyName = "sprav_po";
            this.spravpoDataGridViewTextBoxColumn.HeaderText = "Справ ПО";
            this.spravpoDataGridViewTextBoxColumn.Name = "spravpoDataGridViewTextBoxColumn";
            // 
            // spravoborudDataGridViewTextBoxColumn
            // 
            this.spravoborudDataGridViewTextBoxColumn.DataPropertyName = "sprav_oborud";
            this.spravoborudDataGridViewTextBoxColumn.DataSource = this.sspravoborudBindingSource;
            this.spravoborudDataGridViewTextBoxColumn.DisplayMember = "nazv";
            this.spravoborudDataGridViewTextBoxColumn.HeaderText = "Справочник оборудования";
            this.spravoborudDataGridViewTextBoxColumn.Name = "spravoborudDataGridViewTextBoxColumn";
            this.spravoborudDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.spravoborudDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.spravoborudDataGridViewTextBoxColumn.ValueMember = "cod";
            // 
            // polz1DataGridViewTextBoxColumn
            // 
            this.polz1DataGridViewTextBoxColumn.DataPropertyName = "polz_1";
            this.polz1DataGridViewTextBoxColumn.DataSource = this.polzovBindingSource;
            this.polz1DataGridViewTextBoxColumn.DisplayMember = "fam";
            this.polz1DataGridViewTextBoxColumn.HeaderText = "Пользователь 1";
            this.polz1DataGridViewTextBoxColumn.Name = "polz1DataGridViewTextBoxColumn";
            this.polz1DataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.polz1DataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.polz1DataGridViewTextBoxColumn.ValueMember = "cod";
            // 
            // polz2DataGridViewTextBoxColumn
            // 
            this.polz2DataGridViewTextBoxColumn.DataPropertyName = "polz_2";
            this.polz2DataGridViewTextBoxColumn.DataSource = this.polzovBindingSource1;
            this.polz2DataGridViewTextBoxColumn.DisplayMember = "fam";
            this.polz2DataGridViewTextBoxColumn.HeaderText = "Пользователь 2";
            this.polz2DataGridViewTextBoxColumn.Name = "polz2DataGridViewTextBoxColumn";
            this.polz2DataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.polz2DataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.polz2DataGridViewTextBoxColumn.ValueMember = "cod";
            // 
            // polz3DataGridViewTextBoxColumn
            // 
            this.polz3DataGridViewTextBoxColumn.DataPropertyName = "polz_3";
            this.polz3DataGridViewTextBoxColumn.DataSource = this.polzovBindingSource2;
            this.polz3DataGridViewTextBoxColumn.DisplayMember = "fam";
            this.polz3DataGridViewTextBoxColumn.HeaderText = "Пользователь 3";
            this.polz3DataGridViewTextBoxColumn.Name = "polz3DataGridViewTextBoxColumn";
            this.polz3DataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.polz3DataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.polz3DataGridViewTextBoxColumn.ValueMember = "cod";
            // 
            // ObrashForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1380, 665);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.bindingNavigator1);
            this.Controls.Add(this.statusStrip1);
            this.Name = "ObrashForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Обращение";
            this.Load += new System.EventHandler(this.ObrashForm_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.obrashBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._db_pc_techDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.obrashBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeobrBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sspravoborudBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sspravoborudBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.polzovBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.polzovBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.polzovBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.obrashBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.BindingSource bindingSource1;
        private _db_pc_techDataSet _db_pc_techDataSet;
        private System.Windows.Forms.BindingSource obrashBindingSource;
        private _db_pc_techDataSetTableAdapters.ObrashTableAdapter obrashTableAdapter;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.BindingSource statusBindingSource;
        private _db_pc_techDataSetTableAdapters.StatusTableAdapter statusTableAdapter;
        private System.Windows.Forms.BindingSource obrashBindingSource1;
        private System.Windows.Forms.BindingSource typeobrBindingSource;
        private _db_pc_techDataSetTableAdapters.Type_obrTableAdapter type_obrTableAdapter;
        private System.Windows.Forms.BindingSource sspravoborudBindingSource;
        private _db_pc_techDataSetTableAdapters.Ssprav_oborudTableAdapter ssprav_oborudTableAdapter;
        private System.Windows.Forms.BindingSource sspravoborudBindingSource1;
        private System.Windows.Forms.BindingSource polzovBindingSource;
        private _db_pc_techDataSetTableAdapters.PolzovTableAdapter polzovTableAdapter;
        private System.Windows.Forms.BindingSource polzovBindingSource1;
        private System.Windows.Forms.BindingSource polzovBindingSource2;
        private System.Windows.Forms.BindingSource obrashBindingSource2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn codDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataregDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datarazreshDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn opisDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn otlojDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn typeobrashDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn spravpoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn spravoborudDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn polz1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn polz2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn polz3DataGridViewTextBoxColumn;
    }
}